import flet as ft

def main(page: ft.Page):
    page.window_width=300
    page.window_height=600
    page.window_always_on_top = True
    page.vertical_alignment = 'center'
    page.horizontal_alignment='center'
    page.theme_mode='dark'    
    page.title='COUNTER'
    
    counter=ft.Text(0, size=80, font_family='Montserrat', weight='bold')
    
    def add_val(e):
        counter.value += 1
        
        if counter.value >=5:
            counter.color='red'
        
        page.update()

    btn = ft.FloatingActionButton(icon='add', on_click=add_val, bgcolor='blue', tooltip='Qo`shish')
    
    page.add(
        counter,
        btn     
    )
    

ft.app(target=main, view='flet_app')